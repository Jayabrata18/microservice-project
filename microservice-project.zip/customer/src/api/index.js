
module.exports = {
    customer: require('./customer'),
    products: require('./products'),
    shopping: require('./shopping')
}
